jQuery(document).scroll(function () {
    var y = jQuery(this).scrollTop();
    if (y >= 300) {
        jQuery(".go-to-top").fadeIn();
    } else {
        jQuery(".go-to-top").fadeOut();
    }
});

jQuery(".go-to-top").click(function () {
    jQuery(window).scrollTop(0);
});

jQuery(".mobile-icon").click(function () {
    jQuery('.navbar-nav').toggle();
});
